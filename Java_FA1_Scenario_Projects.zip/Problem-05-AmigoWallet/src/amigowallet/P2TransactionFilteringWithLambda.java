package amigowallet;

import java.util.List;
import java.util.function.Predicate;

public class P2TransactionFilteringWithLambda {

	public static void main(String[] args) {
		List<Transaction> transactionList = Transaction.getTransactions();
		System.out.println("Transactions less than equal to 1000:");
		filterTransactions(transactionList, (t) -> t.getAmount() <= 1000);
		System.out.println("Transactions more than 1000 and less than equal to 3000:");
		filterTransactions(transactionList, (t) -> t.getAmount() > 1000 && t.getAmount() <= 3000);
		System.out.println("Transactions above 3000:");
		filterTransactions(transactionList, (t) -> t.getAmount() > 3000);
		System.out.println("Debit Transactions:");
		filterTransactions(transactionList, (t) -> t.getType().equals("DEBIT"));
	}
	
	public static void filterTransactions(List<Transaction> transactionList, Predicate<Transaction> predicate) {
		for (Transaction transaction : transactionList)
			if(predicate.test(transaction))
				System.out.println(transaction);
	}
}
