package amigowallet;

import java.util.List;

public class P1TransactionSorting {
	public static void main(String[] args) {
		List<Transaction> transactionList = Transaction.getTransactions();
		showTransactionsLatestFirst(transactionList);
	}

	public static void showTransactionsLatestFirst(List<Transaction> transactionList) {
		transactionList.sort((x, y) -> -x.getTime().compareTo(y.getTime()));

		System.out.println("Transactions in descending order of time: ");
		for (Transaction transaction : transactionList)
			System.out.println(transaction);
	}
}
