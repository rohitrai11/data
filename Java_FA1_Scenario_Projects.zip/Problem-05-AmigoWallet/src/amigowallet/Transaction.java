package amigowallet;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

public class Transaction {
	private Integer transationId;
	private LocalDateTime time;
	private String type;
	private String remarks;
	private Double amount;
	
	public Transaction(Integer transationId, LocalDateTime time, String type, String remarks, Double amount) {
		super();
		this.transationId = transationId;
		this.time = time;
		this.type = type;
		this.remarks = remarks;
		this.amount = amount;
	}

	public Integer getTransationId() {
		return transationId;
	}

	public void setTransationId(Integer transationId) {
		this.transationId = transationId;
	}

	public LocalDateTime getTime() {
		return time;
	}

	public void setTime(LocalDateTime transactionTime) {
		this.time = transactionTime;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}
	
	@Override
	public String toString() {
		return "Transaction id: " + this.transationId + ", Time: " + this.time + ", type: " + this.type + ", Amount: " + this.amount + ", Remarks: " + this.remarks;
	}
	
	// Sample data for transactions
	public static List<Transaction> getTransactions() {
		return Arrays.asList(
				new Transaction(1001134, LocalDateTime.of(2017, 4, 3, 11, 23, 31), "DR", "Paid phone bill", 533.0),
				new Transaction(1001453, LocalDateTime.of(2017, 3, 12, 16, 32, 42), "DR", "Paid internet bill", 800.0),
				new Transaction(1001271, LocalDateTime.of(2017, 3, 8, 19, 37, 38), "CR", "From bank account", 12000.0),
				new Transaction(1001014, LocalDateTime.of(2017, 4, 22, 9, 49, 19), "DR", "Paid electricity bill", 672.0),
				new Transaction(1001521, LocalDateTime.of(2017, 3, 17, 12, 17, 42), "CR", "From Jim", 15000.0),
				new Transaction(1001343, LocalDateTime.of(2017, 4, 15, 14, 13, 2), "DR", "To bank account", 1500.0)
				);
	}
}