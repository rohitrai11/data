package amigowallet;

import java.util.List;

public class P2TransactionFilteringWithoutLambda {

	public static void main(String[] args) {
		List<Transaction> transactionList = Transaction.getTransactions();
		showTransactionsBelow1000(transactionList);
		showTransactions1000To3000(transactionList);
		showTransactionsAbove3000(transactionList);
	}
	
	public static void showTransactionsBelow1000(List<Transaction> transactionList) {
		System.out.println("Transactions below 1000:");
		for (Transaction transaction : transactionList)
			if(transaction.getAmount() <= 1000) System.out.println(transaction);
	}
	
	public static void showTransactions1000To3000(List<Transaction> transactionList) {
		System.out.println("Transactions between 1000 and 3000:");
		for (Transaction transaction : transactionList)
			if(transaction.getAmount() > 1000 && transaction.getAmount() <= 3000)
				System.out.println(transaction);
	}
	
	public static void showTransactionsAbove3000(List<Transaction> transactionList) {
		System.out.println("Transactions above 3000:");
		for (Transaction transaction : transactionList)
			if(transaction.getAmount() > 3000) System.out.println(transaction);
	}
	
	/*public static void showDebitTransactions(List<Transaction> transactionList) {
	System.out.println("Debit Transactions:");
	for (Transaction transaction : transactionList)
		if(transaction.getType().equals("DEBIT")) System.out.println(transaction);
	}*/
}
