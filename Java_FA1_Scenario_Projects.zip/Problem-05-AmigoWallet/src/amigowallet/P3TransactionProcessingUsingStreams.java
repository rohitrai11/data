package amigowallet;

import java.util.List;

public class P3TransactionProcessingUsingStreams {

	public static void main(String[] args) {
		List<Transaction> list = Transaction.getTransactions();
		transactionsAbove10k(list);
	}
	
	public static void transactionsAbove10k(List<Transaction> transactionList) {
		//LocalTime start = LocalTime.now();
		System.out.println("Transactions above 10000:");
		
		// Using streams
		transactionList.stream().filter(t -> t.getAmount() > 10000)
	        .map(t -> t.getTransationId())
	        .sorted()
	        .forEach(id -> System.out.println(id));
	}
}
