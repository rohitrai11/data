package emart;

public class BillCalculator {
	private int billId;
	private float amount;

	public void processOrder(Product[] products) {

		for (int i = 0; i < products.length; i++) {

			if (products[i].getStock() <= 0) {
				// To do (for Tester2): Use the following line to inform about out of stock products
				System.out.println(products[i].getName() + " out of stock"); break;
			}
			else {
				this.amount += products[i].getPrice();
				products[i].setStock(products[i].getStock() - 1);
			}
		}
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public int getBillId() {
		return billId;
	}

	public void setBillId(int billId) {
		this.billId = billId;
	}
}
