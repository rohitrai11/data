package chillngrill;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class P2RemovingDuplicates {

	public static void main(String[] args) {
		List<String> orders = new ArrayList<String>();
		orders.add("Tortilla");
		orders.add("Sandwich");
		orders.add("Fried rice");
		orders.add("Pasta");
		orders.add("Burger");
		orders.add("Pizza");
		orders.add("Pasta");
		orders.add("Burger");
		
		Set<String> uniqueItems = new HashSet<String>();
		uniqueItems.addAll(orders);
		
		System.out.println(uniqueItems);
	}
}
