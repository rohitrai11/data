package chillngrill;

import java.util.ArrayList;
import java.util.List;

public class P1ProcessingOrders {
	
	static List<String> orders = new ArrayList<>();

	public static void main(String[] args) {
		addOrder("Tortilla");		// Adding elements into the list
		addOrder("Sandwich");
		addOrder("Pasta");
		addOrder("Burger");
		addOrder("Pizza");
		addOrder("Pasta");
		addOrder("Burger");
		
		removeOrder(2);				// Removing elements from the list
		
		System.out.println(orders);
	}
	
	public static void addOrder(String order) {
	    orders.add(order);
	}

	public static void removeOrder(int orderIndex) {
	    orders.remove(orderIndex);
	}
}
