package chillngrill;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class P3AnalyzingDemand {

	public static void main(String[] args) {
		// Sample list of orders
		List<String> orders = new ArrayList<String>();
		orders.add("Tortilla");
		orders.add("Sandwich");
		orders.add("Fried rice");
		orders.add("Pasta");
		orders.add("Burger");
		orders.add("Pizza");
		orders.add("Pasta");
		orders.add("Burger");

		Map<String, Integer> itemMap = new HashMap<String, Integer>();

		for(String item : orders) {
		    if(itemMap.containsKey(item)) {
		        itemMap.put(item, itemMap.get(item) + 1);
		    }
		    else itemMap.put(item, 1);
		}
		
		System.out.println(itemMap);
	}
}
