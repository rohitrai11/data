package hitech;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

public class Call {
	private String callId;
	private LocalDateTime startTime;
	private LocalDateTime endTime;
	
	// Parameterized constructor, getters and setters
	public Call(String callId, LocalDateTime startTime, LocalDateTime endTime) {
		super();
		this.callId = callId;
		this.startTime = startTime;
		this.endTime = endTime;
	}
	
	public String getCallId() {
		return callId;
	}

	public void setCallId(String callId) {
		this.callId = callId;
	}

	public LocalDateTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}

	public LocalDateTime getEndTime() {
		return endTime;
	}

	public void setEndTime(LocalDateTime endTime) {
		this.endTime = endTime;
	}

	// Static method to provide a sample list of calls for a user
    public static List<Call> getList() {
        return Arrays.asList(
                new Call("c10006", LocalDateTime.of(2017, 8, 12, 4, 23, 19), LocalDateTime.of(2017, 8, 12, 4, 37, 43)),
                new Call("c10004", LocalDateTime.of(2017, 8, 14, 23, 12, 52), LocalDateTime.of(2017, 8, 14, 23, 42, 7)),
                new Call("c10023", LocalDateTime.of(2017, 8, 15, 7, 42, 37), LocalDateTime.of(2017, 8, 15, 8, 22, 28)),
                new Call("c10033", LocalDateTime.of(2017, 8, 15, 8, 57, 9), LocalDateTime.of(2017, 8, 15, 9, 34, 16)),
                new Call("c10041", LocalDateTime.of(2017, 8, 15, 14, 44, 10), LocalDateTime.of(2017, 8, 15, 15, 16, 17)),
                new Call("c10043", LocalDateTime.of(2017, 8, 15, 23, 4, 15), LocalDateTime.of(2017, 8, 15, 23, 18, 11)),
                new Call("c10051", LocalDateTime.of(2017, 8, 18, 16, 27, 29), LocalDateTime.of(2017, 8, 18, 17, 6, 41)),
                new Call("c10053", LocalDateTime.of(2017, 8, 24, 19, 13, 31), LocalDateTime.of(2017, 8, 24, 19, 47, 38))
                );
    }
}
