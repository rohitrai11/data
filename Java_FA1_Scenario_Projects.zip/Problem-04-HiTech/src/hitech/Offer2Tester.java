package hitech;

import java.time.LocalDateTime;
import java.util.List;

public class Offer2Tester {
	public static void main(String[] args) {
		List<Call> calls = Call.getList();
		
		// Filtering calls made on 15th August 2017 from 8:00 am to 11:00 pm
		for(Call call : calls) {
			if(!isCallEligible(call.getStartTime()))
				System.out.println("Call " + call.getCallId() + " is not eligible");
			else
				System.out.println("Call " + call.getCallId() + " is eligible");
		}
	}
	
	public static boolean isCallEligible(LocalDateTime callStartTime) {
		LocalDateTime offerStartTime = LocalDateTime.of(2017, 8, 15, 8, 0, 0);
		LocalDateTime offerEndTime = LocalDateTime.of(2017, 8, 15, 23, 0, 0);
		if(callStartTime.isBefore(offerStartTime) || callStartTime.isAfter(offerEndTime))
			return false;
		else return true;
	}
}
