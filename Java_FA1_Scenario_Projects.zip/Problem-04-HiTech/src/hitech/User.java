package hitech;

import java.util.Arrays;
import java.util.List;

public class User {
	private String username;
	private String email;
	private String dob;
	
	// Parameterized constructor, getters and setters
	public User(String username, String email, String dob) {
		super();
		this.username = username;
		this.email = email;
		this.dob = dob;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}
	
	// Static method to provide a sample list of users
    public static List<User> getList() {
        return Arrays.asList(
                new User("Jill", "jill@ymail.com", "10-Jul-1998"),
                new User("John", "john@ymail.com", "14-Mar-1967"),
                new User("Jack", "jack@ymail.com", "17-Feb-2002"),
                new User("Jamie", "jamie@ymail.com", "23-Jul-1972"),
                new User("Jax", "jax@ymail.com", "06-Sep-1959"),
                new User("Jim", "jim@ymail.com", "26-Aug-1962"),
                new User("Jora", "jill@ymail.com", "11-Dec-1981")
                );
    }
}
