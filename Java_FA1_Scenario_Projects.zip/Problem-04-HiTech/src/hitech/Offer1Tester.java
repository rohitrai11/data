package hitech;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class Offer1Tester {
	
	public static void main(String[] args) {
		List<User> users = User.getList();
		
		// Filtering users of age 50 or more
		for(User user : users) {
			if(!isAgeEligible(stringToLocalDate(user.getDob())))
				System.out.println(user.getUsername() + " is not eligible");
			else
				System.out.println(user.getUsername() + " is eligible");
		}
	}
	
	public static boolean isAgeEligible(LocalDate dob) {
		LocalDate today = LocalDate.now();
		if(dob.until(today, ChronoUnit.YEARS) >= 50)
		    return true;
		else return false;
	}
	
	public static LocalDate stringToLocalDate(String date) {
		String pattern = "dd-MMM-yyyy";
		return LocalDate.parse(date, DateTimeFormatter.ofPattern(pattern));
	}
}
