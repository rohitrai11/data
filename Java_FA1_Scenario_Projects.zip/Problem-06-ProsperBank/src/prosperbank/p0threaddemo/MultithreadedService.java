package prosperbank.p0threaddemo;

public class MultithreadedService {

	public static void main(String[] args) {
		CustomerThread thread1 = new CustomerThread("Customer 1");
		CustomerThread thread2 = new CustomerThread("Customer 2");
		CustomerThread thread3 = new CustomerThread("Customer 3");
		CustomerThread thread4 = new CustomerThread("Customer 4");
		CustomerThread thread5 = new CustomerThread("Customer 5");
		CustomerThread thread6 = new CustomerThread("Customer 6");
		CustomerThread thread7 = new CustomerThread("Customer 7");
		CustomerThread thread8 = new CustomerThread("Customer 8");
		CustomerThread thread9 = new CustomerThread("Customer 9");
		CustomerThread thread10 = new CustomerThread("Customer 10");
		
		thread1.start();
		thread2.start();
		thread3.start();
		thread4.start();
		thread5.start();
		thread6.start();
		thread7.start();
		thread8.start();
		thread9.start();
		thread10.start();
	}
}

class CustomerThread extends Thread {
	private String name;
	
	public CustomerThread(String name) {
		this.name = name;
	}
	
	@Override
	public void run() {
		try {
			Thread.sleep(10);			// Introducing delay of 10 ms
		} catch (InterruptedException e) { e.printStackTrace();}
		System.out.println(this.name + " has been served");
	}
}
