package application;

import java.time.LocalDateTime;

public class Tester {
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		String examStartString = "24 August, 2017, 9:30 AM";
		String examEndString = "24 August, 2017, 11:30 AM";

		// Code here
	}

	public static boolean isValidExamDateTime(String examStartString, String examEndString) throws Exception {
		// Code here
		return false;
	}

	public static LocalDateTime getDateTimeFromString(String dateStr) {
		// Code here
		return null;
	}
}
