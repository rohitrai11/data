package test;

public class ApplicationTest {
	
	public void validExam() throws Exception {

	}
	
	public void invalidExamDuration() throws Exception {
		
	}
	
	public void invalidExamSlot() throws Exception {
		
	}
	
	public void invalidExamPastDate() throws Exception {
		
	}
	
	public void invalidExamWeekend() throws Exception {
		
	}
	
	public void invalidExamDateAfter7Days() throws Exception {
		
	}
	
	public void invalidDateTimeFormat() throws Exception {
		
	}
}
