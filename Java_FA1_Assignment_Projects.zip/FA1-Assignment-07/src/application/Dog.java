package application;

public class Dog {
	// Code here
}
