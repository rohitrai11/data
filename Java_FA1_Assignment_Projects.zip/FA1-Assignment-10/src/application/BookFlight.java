package application;

import java.util.concurrent.Callable;

public class BookFlight implements Callable<BookFlight> {

	@Override
	public BookFlight call() throws Exception {
		// Code here
		return null;
	}
}
