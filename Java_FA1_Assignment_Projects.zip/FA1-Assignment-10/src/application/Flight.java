package application;

public class Flight {
	// Code here
}
