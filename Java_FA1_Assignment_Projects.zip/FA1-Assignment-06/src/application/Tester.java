package application;

class ComplexNumber {
	// Code here
}

public class Tester {
	public static void main(String[] args) {
		// Code here
	}
}
