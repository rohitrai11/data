package application;

public enum ItemType {
	GOLD, SILVER
}
