package application;

import java.util.List;
import java.util.stream.Stream;

public class Tester {
	public static void main(String[] args) {
		// Code here
	}
	
	public static Stream<Item> sortAccordingToWeight(Stream<Item> items) {
		// Code here
		return null;
	}
	
	public static Stream<Item> calculatePricePerItem(Stream<Item> items) {
		// Code here
		return null;
	}
	
	public static Stream<Item> filterItemsByType(List<Item> items, ItemType itemType) {
		// Code here
		return null;
	}
}
