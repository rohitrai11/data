package application;

public class Item {
	// Code here
}
