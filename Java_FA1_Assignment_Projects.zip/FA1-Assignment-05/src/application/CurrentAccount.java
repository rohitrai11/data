package application;

public class CurrentAccount {
	// Code here
}
