package application;

public class Account {
	// Code here
}