package application;

public class SavingsAccount {
	// Code here
}