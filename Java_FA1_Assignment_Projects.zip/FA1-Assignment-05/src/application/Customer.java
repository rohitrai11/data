package application;

public class Customer {
	// Code here
}
