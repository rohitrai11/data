package test;

public class ApplicationTest {
	
	public void invalidSavingsWithdraw() throws Exception {
		
	}
	
	public void validSavingsWithdraw() throws Exception {
		
	}
	
	public void invalidCurrentWithdraw() throws Exception {
		
	}
	
	public void validCurrentWithdraw() throws Exception {
		
	}
}
