package test;

public class ApplicationTest {

	public void bookAssessmentInvalidBatchName()throws Exception{
		// Write the code to test
	}
	
	public void bookAssessmentInvalidEmailId()throws Exception{
		// Write the code to test
	}
	
	public void getAssessmentReportNotFound()throws Exception{
		// Write the code to test
	}
}
