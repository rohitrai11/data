package application;

import java.time.LocalDate;
import java.util.List;

public class Validator {
	public void validate(Booking booking) throws Exception {
		// Use isValidBatchName, isValidCourseName, isValidAssessmentDate, isValidAssessmentType, isValidEmailId to validate the booking details
		// For invalid inputs throw exceptions with the corresponding messages
	}
	
	public Boolean isValidBatchName(String batchName) {
		return null;
	}

	public Boolean isValidCourseName(String courseName) {
		return null;
	}
	
	public Boolean isValidAssessmentDate(LocalDate assessmentDate) {
		return null;
	}

	
	public Boolean isValidAssessmentType(String assessmentType) {
		return null;
	}

	public Boolean isValidEmailId(List<Trainee>traineesList) {
		return null;
	}
}
