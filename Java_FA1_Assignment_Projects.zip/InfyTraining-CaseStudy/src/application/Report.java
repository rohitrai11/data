package application;

public class Report {
	
	// Implement the class as per class diagram 
}
