package application;

public class CourseRegistration {
	// Code here
}
