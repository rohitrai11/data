package application;

public interface Certification {
	// Code here
}
