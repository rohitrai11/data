package application;

public class EPayWallet {
	// Code here
}
