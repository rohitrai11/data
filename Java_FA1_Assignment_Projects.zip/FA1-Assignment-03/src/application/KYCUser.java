package application;

public class KYCUser {
	// Code here
}
