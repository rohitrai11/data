package application;

public class User {
	// Code here
}
