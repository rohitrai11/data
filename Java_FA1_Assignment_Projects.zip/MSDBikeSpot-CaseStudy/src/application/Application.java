package application;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;


public class Application {

	public String addBikes(List<Bike> bikeList) throws Exception{
		return null;
	}
	
	
	public Set<BikeReport> getBikeDetails(LocalDate model) throws Exception{
		return null;
	}
}
