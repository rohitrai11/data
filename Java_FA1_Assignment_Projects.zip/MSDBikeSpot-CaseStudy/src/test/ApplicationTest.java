package test;

public class ApplicationTest {
	
	public void addBikeValidDetails() throws Exception {
		// Write the code to test
	 }
	 
	public void addBikeValidInValidBikeName() throws Exception {
		// Write the code to test
	 }
	 
	public void getBikeDetailsValidmodel() throws Exception{
		// Write the code to test
	 }
	
	public void getBikeDetailsInValidmodel() throws Exception{
		// Write the code to test
	 }
}
