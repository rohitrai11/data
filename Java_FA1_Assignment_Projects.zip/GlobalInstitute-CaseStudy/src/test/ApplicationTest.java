package test;

public class ApplicationTest {
	
	public void addStudentInvalidDepartment() throws Exception {
		// Write the code to test
	}
	
	public void addStudentInvalidMarks() throws Exception {
		// Write the code to test
	}

	public void addStudentInvalidStudentId() throws Exception {
		// Write the code to test
	}
}
