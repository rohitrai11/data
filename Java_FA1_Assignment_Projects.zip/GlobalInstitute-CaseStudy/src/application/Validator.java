package application;

public class Validator {

	public void validate(Student student) throws Exception {
		// Use isValidStudentName, isValidStudentId, isValidDepartment, isValidExamMarks, isValidResult to validate the student details
		// For invalid inputs throw exceptions with the corresponding messages
	}

	// The entered student name should contain only alphabets and spaces. 
	// Name cannot start with a space
	public Boolean isValidStudentName(String studentName) {
		return null;
	}

	
	// The entered student ID can be any valid 4 digit number greater than or equal to 1001
	public Boolean isValidStudentId(Integer studentId) {
		return null;
	}

	// The entered Department name should be one among the given departments
	// (ECE, CSE, IT)
	public Boolean isValidDepartment(String department) {
		return null;
	}

	// Checking if marks set are not less than "0"
	public Boolean isValidExamMarks(Student student) {
		return null;
	}

	// Checking if result set is either 'P' or 'F' only
	public Boolean isValidResult(Character result) {
		return null;
	}
}
